import json

def lambda_handler(event, context):

	val1 = event['BasePremiumResults']['BasePremium']
	val2 = event['InspModifierResults']['InspectionModifier']
	val3 = event['CrashModifierResults']['CrashModifier']
	# val4 = event['CrimeModifierResults']['CrimeModifier']
	# finalpremium = float(val1) * float(val2)  * float(val3) * float(val4)
	finalpremium = float(val1) * float(val2)  * float(val3)
	return {"FinalPremium": finalpremium}