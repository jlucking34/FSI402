import time
import boto3
import json

# athena constant
DATABASE = 'raas'

# S3 constants
ssm = boto3.client('ssm')
paramdict = ssm.get_parameter(Name='fsi402bucketsuffix', WithDecryption=False)
param = paramdict['Parameter']['Value']
S3_OUTPUT = 's3://fsi402-data-' + param + '/'
S3_BUCKET = 'fsi402-data-' + param

# number of retries
RETRY_COUNT = 10

#---------------------------------------------------------------------------------------------------------------
def delete_s3_objects(query_execution_id):
    # If you want to delete output file
    # s3 client
    client = boto3.client('s3')
    

    # created s3 object
    s3_objects_key = []
    s3_object_key_csv = query_execution_id + '.csv'
    s3_objects_key.append({'Key': s3_object_key_csv})
    s3_object_key_metadata = query_execution_id + '.csv.metadata'
    s3_objects_key.append({'Key': s3_object_key_metadata})

    # delete s3 object
    for i in range(1, 1 + RETRY_COUNT):
        response = client.delete_objects(
            Bucket=S3_BUCKET,
            Delete={
                'Objects': s3_objects_key
                }
        )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            print("delete %s complete" % s3_objects_key)
            break
        else:
            print(response['ResponseMetadata']['HTTPStatusCode'])
            time.sleep(i)
    else:
        raise Exception('object %s delete failed' % s3_objects_key)

#---------------------------------------------------------------------------------------------------------------    
def lambda_handler(event, context):
    # get keyword
    keyword = event['data']['dotnum']
    
    # created query
    query = "SELECT (robbery + property_crime + motor_vehicle_theft) TotalCrime, population Pop FROM %s.crimes c INNER JOIN %s.dots d ON UPPER(d.phy_city) = UPPER(c.city) WHERE d.dot_number = '%s';" % (DATABASE, DATABASE, keyword)
    
    # athena client
    client = boto3.client('athena')
    
    # Execution
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': DATABASE
        },
        ResultConfiguration={
            'OutputLocation': S3_OUTPUT,
        }
    )
    
    # get query execution id
    query_execution_id = response['QueryExecutionId']
    print(query_execution_id)

    # get execution status
    for i in range(1, 1 + RETRY_COUNT):
        # get query execution
        query_status = client.get_query_execution(QueryExecutionId=query_execution_id)
        query_execution_status = query_status['QueryExecution']['Status']['State']

        if query_execution_status == 'SUCCEEDED':
            print("STATUS:" + query_execution_status)
            break

        if query_execution_status == 'FAILED':
            raise Exception("STATUS:" + query_execution_status)

        else:
            print("STATUS:" + query_execution_status)
            time.sleep(i)
    else:
        client.stop_query_execution(QueryExecutionId=query_execution_id)
        raise Exception('TIME OVER')

    # get query results
    result = client.get_query_results(QueryExecutionId=query_execution_id)
    print(result)
    delete_s3_objects(query_execution_id)
    
    # get data
    if len(result['ResultSet']['Rows']) == 2:
        totalcrimes = int(result['ResultSet']['Rows'][1]['Data'][0]['VarCharValue'])
        population = int(result['ResultSet']['Rows'][1]['Data'][1]['VarCharValue'])
        if int(totalcrimes) == 0 or int(population) == 0:
            crimemod = 1
        else:
            crimemod = 1 + (5 * (totalcrimes / population))
        
        return{
            "TotalCrimes": totalcrimes,
            "Population": population,
            "Percentage": (totalcrimes / population),
            "CrimeModifier": crimemod,
        	}
    else:
        return None