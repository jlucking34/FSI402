import time
import json

def lambda_handler(event, context):

# Factors (Future: add to an ISO Lookup table)
	per100k = 15
	baselighttruck = .7
	basemedtruck = .85
	baseheavytruck = 1

	time.sleep(1)

# Base Premium Formulas for Light, Medium & Heavy Trucks
	lighttruck = event['data']['lighttrucks'] * baselighttruck * (per100k * (event['data']['coverage']/100000))
	medtruck = event['data']['medtrucks'] * basemedtruck * (per100k * (event['data']['coverage']/100000))
	heavytruck = event['data']['heavytrucks'] * baseheavytruck * (per100k * (event['data']['coverage']/100000))
	basepremium = (lighttruck + medtruck + heavytruck) * event['data']['policyterm']

	return {"BasePremium": basepremium}