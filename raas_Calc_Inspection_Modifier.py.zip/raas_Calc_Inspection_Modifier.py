import time
import boto3
import json

# athena constants
DATABASE = 'raas'
TABLE = 'inspections'

# S3 constants
ssm = boto3.client('ssm')
paramdict = ssm.get_parameter(Name='fsi402bucketsuffix', WithDecryption=False)
param = paramdict['Parameter']['Value']
S3_OUTPUT = 's3://fsi402-data-' + param + '/'
S3_BUCKET = 'fsi402-data-' + param

# number of retries
RETRY_COUNT = 10

# query constant
COLUMN = 'DOT_Number'

#---------------------------------------------------------------------------------------------------------------
def delete_s3_objects(query_execution_id):
    # If you want to delete output file
    # s3 client
    client = boto3.client('s3')
    

    # created s3 object
    s3_objects_key = []
    s3_object_key_csv = query_execution_id + '.csv'
    s3_objects_key.append({'Key': s3_object_key_csv})
    s3_object_key_metadata = query_execution_id + '.csv.metadata'
    s3_objects_key.append({'Key': s3_object_key_metadata})

    # delete s3 object
    for i in range(1, 1 + RETRY_COUNT):
        response = client.delete_objects(
            Bucket=S3_BUCKET,
            Delete={
                'Objects': s3_objects_key
                }
        )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            print("delete %s complete" % s3_objects_key)
            break
        else:
            print(response['ResponseMetadata']['HTTPStatusCode'])
            time.sleep(i)
    else:
        raise Exception('object %s delete failed' % s3_objects_key)

#---------------------------------------------------------------------------------------------------------------    
def lambda_handler(event, context):

    # get keyword
    keyword = event['data']['dotnum']
    # created query
    query1 = "SELECT Count(*) AS TotalInspections FROM %s.%s WHERE %s = %s AND BASIC_Viol = 1;" % (DATABASE, TABLE, COLUMN, keyword)
    query2 = "SELECT Count(*) AS TotalInspections FROM %s.%s WHERE %s = %s;" % (DATABASE, TABLE, COLUMN, keyword)
    
    # athena client
    client = boto3.client('athena')

    # Execute Queries
    q1_response = client.start_query_execution(
        QueryString=query1,
        QueryExecutionContext={
            'Database': DATABASE
        },
        ResultConfiguration={
            'OutputLocation': S3_OUTPUT,
        }
    )
    query1_execution_id = q1_response['QueryExecutionId']

    q2_response = client.start_query_execution(
        QueryString=query2,
        QueryExecutionContext={
            'Database': DATABASE
        },
        ResultConfiguration={
            'OutputLocation': S3_OUTPUT,
        }
    )
    query2_execution_id = q2_response['QueryExecutionId']

    # get query1 execution status
    for i in range(1, 1 + RETRY_COUNT):
        # get query1 execution
        query_status = client.get_query_execution(QueryExecutionId=query1_execution_id)
        query_execution_status = query_status['QueryExecution']['Status']['State']
        if query_execution_status == 'SUCCEEDED':
            print("STATUS Q1:" + query_execution_status)
            break
        if query_execution_status == 'FAILED':
            raise Exception("STATUS Q1:" + query_execution_status)
        else:
            print("STATUS Q1:" + query_execution_status)
            time.sleep(i)
    else:
        client.stop_query_execution(QueryExecutionId=query1_execution_id)
        raise Exception('TIME OVER')

    # get query2 execution status
    for i in range(1, 1 + RETRY_COUNT):
        # get query2 execution
        query_status = client.get_query_execution(QueryExecutionId=query2_execution_id)
        query_execution_status = query_status['QueryExecution']['Status']['State']
        if query_execution_status == 'SUCCEEDED':
            print("STATUS Q2:" + query_execution_status)
            break
        if query_execution_status == 'FAILED':
            raise Exception("STATUS Q2:" + query_execution_status)
        else:
            print("STATUS Q2:" + query_execution_status)
            time.sleep(i)
    else:
        client.stop_query_execution(QueryExecutionId=query2_execution_id)
        raise Exception('TIME OVER')
	
    # get data
    result = client.get_query_results(QueryExecutionId=query1_execution_id)
    delete_s3_objects(query1_execution_id)
    if len(result['ResultSet']['Rows']) == 2:
        violations = result['ResultSet']['Rows'][1]['Data'][0]['VarCharValue']
    else:
        violations = 0
    
    result = client.get_query_results(QueryExecutionId=query2_execution_id)
    delete_s3_objects(query2_execution_id)
    if len(result['ResultSet']['Rows']) == 2:
        inspections = result['ResultSet']['Rows'][1]['Data'][0]['VarCharValue']
    else:
        inspections = 0
    
    # return data
    if violations == 0:
        inspectionmod = 1
    elif inspections == 0:
        inspectionmod = 1
    else:
        inspectionmod = 1 + (violations / inspections)

    return{
        "InspectionModifier": inspectionmod,
        "Violations": violations,
        "Inspections": inspections,
        }